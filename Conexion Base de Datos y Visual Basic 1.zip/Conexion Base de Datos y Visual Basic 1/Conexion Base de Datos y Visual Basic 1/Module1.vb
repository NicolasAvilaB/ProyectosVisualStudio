﻿Imports System.Data.SqlClient
Module Module1
    Friend Conexion1 As New SqlConnection
    Friend SC1 As New SqlCommand
    Friend DA1 As New SqlDataAdapter
    Friend DS1 As New DataSet()
    Friend DT1 As New DataTable

End Module

