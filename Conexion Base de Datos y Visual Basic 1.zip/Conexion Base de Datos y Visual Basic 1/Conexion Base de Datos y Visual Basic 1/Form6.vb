﻿Public Class Form6

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
    Sub limpiar()
        TxtNombre.Clear()
        TxtPrecio.Clear()
        TxtCantidad.Clear()

    End Sub
    Sub Control(ByVal a As Boolean, ByVal b As Boolean)
        TxtNombre.ReadOnly = b
        TxtPrecio.ReadOnly = b
        TxtCantidad.ReadOnly = b

        BtAgregarProducto.Enabled = a
        BtQuitar.Enabled = a
        BtNuevaVenta.Enabled = b
        BtGrabarVenta.Enabled = a
        BtCancelar.Enabled = a
        BtBuscar.Enabled = b
        TxtBuscar.ReadOnly = a
    End Sub
    Sub crearnumeroventa()
        Mionsulta("select max(n_venta) as Vnventa from venta")
        If TypeOf (DS1.Tables(DT1.TableName).Rows(0).Item("Vnventa")) Is DBNull Then
            TxtNventa.Text = 1
        Else
            TxtNventa.Text = DS1.Tables(DT1.TableName).Rows(0).Item("Vnventa") + 1
        End If
        Conexion1.Close()
    End Sub
    Private Sub Form6_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Conexion1.ConnectionString = "Data Source=NICO-PC;Initial Catalog=BASEVENTAS;user Id=sa; Password =aiep123+*;"

        TxtFecha.Text = FormatDateTime(Now, DateFormat.ShortDate)

    End Sub

    Private Sub BtNuevaVenta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtNuevaVenta.Click
        crearnumeroventa()
        Control(True, False)
        DataGridView1.Rows.Clear()
    End Sub
End Class