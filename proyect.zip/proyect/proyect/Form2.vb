﻿Public Class Form2

    Private Sub BTIngrese_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTIngrese.Click
        Form3.Show()
    End Sub
End Class