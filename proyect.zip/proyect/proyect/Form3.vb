﻿Public Class Form3

    Private Sub BTClientes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTClientes.Click
        Form4.Show()
    End Sub

    Private Sub BTReservas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTReservas.Click
        Form7.Show()
    End Sub

    Private Sub BTSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTSalir.Click


    End Sub

    Private Sub BTConsultaLibro_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTConsultaLibro.Click
        Form5.Show()
    End Sub
End Class