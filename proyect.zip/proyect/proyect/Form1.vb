﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BTIngresar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTIngresar.Click
        Form2.Show()
    End Sub
End Class
