﻿Imports System.Data.SqlClient
Module ModuleConexiones
    Friend conexion As New SqlConnection
    Friend SC As New SqlCommand
    Friend DA As New SqlDataAdapter
    Friend DS As New DataSet()
    Friend DT As New DataTable


    Friend SC2 As New SqlCommand
    Friend DA2 As New SqlDataAdapter
    Friend DS2 As New DataSet()
    Friend DT2 As New DataTable

End Module
