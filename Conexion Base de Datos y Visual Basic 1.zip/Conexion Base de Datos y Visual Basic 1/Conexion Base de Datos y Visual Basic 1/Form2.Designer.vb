﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BTUSUARIOS = New System.Windows.Forms.Button()
        Me.BTCLIENTES = New System.Windows.Forms.Button()
        Me.BTSALIR = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'BTUSUARIOS
        '
        Me.BTUSUARIOS.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTUSUARIOS.Location = New System.Drawing.Point(12, 12)
        Me.BTUSUARIOS.Name = "BTUSUARIOS"
        Me.BTUSUARIOS.Size = New System.Drawing.Size(140, 61)
        Me.BTUSUARIOS.TabIndex = 0
        Me.BTUSUARIOS.Text = "Usuarios"
        Me.BTUSUARIOS.UseVisualStyleBackColor = True
        '
        'BTCLIENTES
        '
        Me.BTCLIENTES.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTCLIENTES.Location = New System.Drawing.Point(167, 12)
        Me.BTCLIENTES.Name = "BTCLIENTES"
        Me.BTCLIENTES.Size = New System.Drawing.Size(140, 61)
        Me.BTCLIENTES.TabIndex = 1
        Me.BTCLIENTES.Text = "Clientes "
        Me.BTCLIENTES.UseVisualStyleBackColor = True
        '
        'BTSALIR
        '
        Me.BTSALIR.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTSALIR.Location = New System.Drawing.Point(13, 89)
        Me.BTSALIR.Name = "BTSALIR"
        Me.BTSALIR.Size = New System.Drawing.Size(294, 46)
        Me.BTSALIR.TabIndex = 2
        Me.BTSALIR.Text = "Salir"
        Me.BTSALIR.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(13, 152)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(139, 61)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Buscar Registros Por ComboBox"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(168, 152)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(139, 61)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Mostrar Datos en DataGridView"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(318, 230)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.BTSALIR)
        Me.Controls.Add(Me.BTCLIENTES)
        Me.Controls.Add(Me.BTUSUARIOS)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BTUSUARIOS As System.Windows.Forms.Button
    Friend WithEvents BTCLIENTES As System.Windows.Forms.Button
    Friend WithEvents BTSALIR As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
End Class
